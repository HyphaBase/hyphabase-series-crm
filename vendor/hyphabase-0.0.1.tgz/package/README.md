# hyphabase

Official JavaScript/TypeScript SDK for [HyphaBase](https://hyphabase.com) — works in React, Next.js, Vue, or any JavaScript app.

Auth ships first; every HyphaBase module (clients, employees, schedules, …) will land here over time on the same client.

## Install

```bash
npm install hyphabase
```

## Quick start

```ts
import { createClient } from "hyphabase";

const hyphabase = createClient(
  "https://api.hyphabase.com",
  "pk_live_...", // publishable key - safe for the browser
  { locationId: "your-location-uuid" },
);
```

## Auth

```ts
// Sign up a new end user (application must enable end-user sign-up)
await hyphabase.auth.signUp({ name, email, password });

// Sign in
await hyphabase.auth.signIn({ email, password });

// Session state
hyphabase.auth.getUser();     // EndUser | null
hyphabase.auth.getSession(); // Session | null

// Sign out (revokes server-side too)
await hyphabase.auth.signOut();
```

### Recovery and verification

```ts
await hyphabase.auth.forgotPassword({ email });            // emails a single-use token; never says if the address exists
await hyphabase.auth.resetPassword({ email, token, password }); // revokes every session, including this one
await hyphabase.auth.verifyEmail({ email, token });         // token arrives at sign-up, or from resendVerification()
await hyphabase.auth.resendVerification();                  // as the signed-in user
```

Your app hosts the forms; the emails carry the token. If the application requires verification, an unverified user gets `403` with `error.type === "email_unverified"` (`error.isEmailUnverified` in the SDK) on everything except the auth calls above.

Every write the SDK makes carries an `Idempotency-Key` (one per call, reused across its own retry), so a request that reaches the API twice is applied once. Pass `idempotencyKey` to `request()` to control it, or `false` to omit it.

### Your profile

```ts
const { user, permissions } = await hyphabase.profile.get();             // who am I, what may I do here
await hyphabase.profile.update({ name: "Riley Quinn", email: user.email, phone: "555-0100" }); // name and email are both required: send the current email to keep it
await hyphabase.profile.changePassword({ current_password, password });    // ends every session, this one included
const { permissions: mine } = await hyphabase.profile.permissions();
```

`changePassword` clears the local session because the API revokes every token the person holds: sign in again with the new password.

### Token lifecycle (handled for you)

Sessions use a **short-lived access token + rotating refresh token**:

- Access tokens expire after ~1 hour; the SDK refreshes them automatically before requests.
- Every refresh **rotates** the refresh token — the old one is consumed. If a stolen refresh token is ever replayed, the server revokes the entire token family.
- Concurrent refreshes are coalesced into one request (rotation makes parallel refreshes self-defeating).
- An unexpected `401` triggers one refresh-and-retry before failing.

## Modules

Typed module namespaces live on the client — `clients` is the first:

```ts
// List, with search + pagination
const page = await hyphabase.clients.list({ search: "ava", page: 1, perPage: 25 });
page.data;        // Client[]
page.meta.total;  // 42

// CRUD
const ava = await hyphabase.clients.create({
  first_name: "Ava", last_name: "Nguyen",
  email: "ava@example.com", phone: "555-0101",
});
await hyphabase.clients.update(ava.id, { phone: "555-9999" });
await hyphabase.clients.get(ava.id);
await hyphabase.clients.delete(ava.id);
await hyphabase.clients.restore(ava.id);
```

### Nested resources

Notes, traits, and addresses are scoped per client; status definitions and import/export are module-level:

```ts
const notes = hyphabase.clients.notes(ava.id);
await notes.create({ category: "general", content: "Prefers oat milk", visibility: "internal" });
await notes.list();

await hyphabase.clients.traits(ava.id).create({ name: "VIP", icon: "star", color: "#f4c04c" });
await hyphabase.clients.addresses(ava.id).list();

await hyphabase.clients.statuses.create({ name: "VIP" });
await hyphabase.clients.locationStatuses(ava.id).assign(locationId, statusId);

const op = await hyphabase.clients.importExport.export({ search: "ava" }); // returns the operation (status "pending")
// ...poll operations.get(op.id) until it completes, then:
const csv = await hyphabase.clients.importExport.operations.download(op.id);
```

Updating a client status is a full update (`PUT`): send its `name` with the change. Notes, traits and addresses update with `PATCH`: only the fields you send change.

Employees (staff at the current location) follow the same shape. Deactivating someone keeps their record but stops them signing in; reactivating restores it:

```ts
const marcus = await hyphabase.employees.create({
  name: "Marcus Lee",
  email: "marcus@glowsalon.example",
  password: "correct horse battery staple",
});
await hyphabase.employees.update(marcus.id, { phone: "555-0200" }); // PATCH: only the fields you send change
await hyphabase.employees.deactivate(marcus.id); // is_active: false
await hyphabase.employees.reactivate(marcus.id);
await hyphabase.employees.delete(marcus.id);
```

Services (the catalog at the current location) take a price and how long they run. `delete` archives; it never rewrites past bookings or invoices:

```ts
const cut = await hyphabase.services.create({
  name: "Signature cut",
  price: 60,
  duration_minutes: 45,
  buffer_time_minutes: 10,
});
await hyphabase.services.update(cut.id, { price: 65 }); // PATCH: only the fields you send change
await hyphabase.services.delete(cut.id);
```

Service groups and add-ons are beta: `services.groups.*` works but its shape may change.

More modules (schedules, …) will land on the same client over time.

### Roles

```ts
const role = await hyphabase.organizations.roles.create({ name: "Front desk", permissions: ["clients.view"] });
await hyphabase.organizations.roles.update(role.id, { name: "Reception" }); // PATCH: only the fields you send change
const same = await hyphabase.organizations.roles.get(role.id);
const all = await hyphabase.organizations.roles.list();
```

## Calling the API directly

`request()` stays available for anything a typed module doesn't cover yet — same auth + location pipeline:

```ts
const guests = await hyphabase.request("/api/modules/clients");

await hyphabase.request("/api/modules/clients", {
  method: "POST",
  body: { first_name: "Ava", last_name: "Nguyen", email: "ava@example.com", phone: "555-0101" },
});
```

## Errors

All failures throw `HyphaBaseError` with `status` and the API's response `body` (including `errors` for 422 validation failures):

```ts
import { HyphaBaseError } from "hyphabase";

try {
  await hyphabase.auth.signUp({ name, email, password });
} catch (err) {
  if (err instanceof HyphaBaseError && err.status === 422) {
    console.log(err.body?.errors); // { email: ["The email has already been taken."] }
  }
}
```

## Custom data (your own collections)

Define your own tables — real Postgres tables in a database of their own per environment, with indexes, unique constraints and foreign keys — and read and write records with a secret key. Server-side only in this release.

```ts
const hb = createClient(url, process.env.HYPHABASE_SECRET_KEY); // data.collections.manage + data.records.*

// Schema: field types are fixed for life; everything else can change later.
await hb.data.collections.create({
  slug: "projects",
  fields: [
    { name: "name", type: "string", required: true, max_length: 200 },
    { name: "status", type: "enum", values: ["active", "done"], default: "active", indexed: true },
    { name: "budget", type: "number", precision: [12, 2] },
    { name: "owner_id", type: "reference", collection: "people", on_delete: "set_null" },
  ],
});
await hb.data.collections.update("projects", [{ op: "add_field", name: "due_on", type: "date", indexed: true }]);
await hb.data.collections.waitUntilReady("projects"); // large tables build indexes in the background

// Records: flat payloads, typed with your own shape.
interface Project { name: string; status: "active" | "done"; budget: number | null; owner_id: string | null; due_on: string | null }
const projects = hb.data.collection<Project>("projects");

const { data: p } = await projects.create({ name: "Website", budget: 1200 });
await projects.update(p.id, { status: "done" });
const page = await projects.list({ filter: { status: "active", budget: { gte: 100 } }, sort: "-created_at", limit: 20 });
for await (const record of projects.iterate({ filter: { status: "done" } })) { /* every page */ }
await projects.delete(p.id);   // soft; restorable; 409 while a `restrict` reference points at it
```

Keys can be limited to one collection with a suffixed scope (`data.records.read:projects`). Deletes are soft and restorable for 30 days, then real.

## Files

Your own files, in the environment's own storage. Bytes go straight to storage
through a short-lived upload URL - the API only ever sees metadata - and come back
through an expiring download URL once the virus scan is clean. A custom-data field
of type `file` holds the id and is a real foreign key.

```ts
const brief = await hb.files.upload(pdfBytes, {
  name: "spring-brief.pdf",
  contentType: "application/pdf",
  metadata: { kind: "brief" },
});

await hb.files.waitUntilScanned(brief.id); // scan_status: clean

await campaigns.create({ name: "Spring", brief: brief.id });

const { url, expires_at } = await hb.files.url(brief.id, { expiresIn: 300 });

await hb.files.delete(brief.id); // soft; restorable for 30 days
```

Scopes: `files.read`, `files.upload`, `files.delete`. A file that records point
at through a `restrict` field refuses deletion with `409` until they let go.

## Webhooks (receiving)

Every delivery carries `HyphaBase-Signature: t=<unix>,v1=<hmac>`. Verify over the
**raw** body with the endpoint's `whsec_` secret before you trust it:

```ts
import { constructWebhookEvent, WebhookSignatureError } from "hyphabase";

app.post("/webhooks/hyphabase", express.raw({ type: "*/*" }), async (req, res) => {
  try {
    const event = await constructWebhookEvent({
      payload: req.body,                                  // Buffer / Uint8Array / string - unparsed
      header: req.header("HyphaBase-Signature"),
      secret: process.env.HYPHABASE_WEBHOOK_SECRET!,
    });
    // event.type, event.data.object
    res.sendStatus(200);
  } catch (err) {
    if (err instanceof WebhookSignatureError) return res.sendStatus(400);
    throw err;
  }
});
```

`verifyWebhookSignature()` is the same check without the parse. Both reject stale
timestamps (5 minutes by default) and compare in constant time; a header with two `v1`
values (secret rotation) passes if either matches. Needs WebCrypto (Node 18+).

## What the SDK does not do

The SDK is for building *applications* on HyphaBase: signing people in and using your modules, custom data and files with an API key. Setting the platform up - your account, applications, environments, locations, API keys, team, billing and webhook endpoints - is done in the console, not here.

## Server-side usage (Node)

The same SDK runs on your backend — pass your **secret key** instead:

```ts
// Node 18+. No session needed: the sk_ key authenticates every request.
const hb = createClient(url, process.env.HYPHABASE_SECRET_KEY, { locationId });

const guests = await hb.clients.list();
await hb.request("/api/modules/employees/users", { method: "POST", body: { ... } });
```

The SDK **refuses to construct with an sk_ key in a browser** — a secret key in frontend code is a leaked secret key. Sessions still win when present, so a server acting on behalf of a signed-in user can use both.

## Security model

- The **publishable key (`pk_`)** is safe to embed: it can only call the rate-limited sign-up endpoint on applications that opted in, and can read nothing.
- **Secret keys (`sk_`) must never be used in a browser.** They belong on your server (the SDK throws if you try).
- End users authenticate with their own credentials; their access is limited by the role your application assigns.

### Where tokens live, honestly

By default sessions persist in `localStorage`, which any script running on your page can read — the same default as Supabase and Firebase. The platform's token design is the safety net for that reality:

- Access tokens die after ~1 hour; refresh tokens are **single-use** and rotate on every refresh.
- A stolen refresh token that gets replayed collides with the legitimate session and the server **revokes the whole token family** — the attacker's session dies the moment the real user is next active.
- Families have an **absolute lifetime** (~30 days from sign-in): a farmed session cannot be kept alive forever, and a **password change revokes everything** immediately.

Your real XSS defense is not storage choice — it is a strict Content-Security-Policy and dependency hygiene. If your threat model still rules out persisted tokens, opt out:

```ts
const hyphabase = createClient(url, pk, {
  locationId,
  persistSession: false, // memory-only: nothing on disk, re-login on page load
});
```

## Development

```bash
npm install
npm test        # vitest
npm run build   # tsup -> dist/
```
